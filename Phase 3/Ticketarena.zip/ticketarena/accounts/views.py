from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from .forms import SignUpForm

def home_page(request):
    return render(request, 'accounts/homepage.html')
def sign_up(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('sign-in') 
    else:
        form = SignUpForm()
    return render(request, 'accounts/sign-up.html', {'form': form})

def sign_in(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('sign-up')
    else:
        form = AuthenticationForm()
    return render(request, 'accounts/sign-in.html', {'form': form})
