from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser

class SignUpForm(UserCreationForm):
    first_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'name-box',  # CSS class for styling
            'placeholder': 'First Name',  # Placeholder text
        })
    )
    last_name = forms.CharField(
        max_length=30,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'name-box',  # CSS class for styling
            'placeholder': 'Last Name',  # Placeholder text
        })
    )
    username = forms.CharField(
        max_length=150,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'input-box',  # CSS class for styling
            'placeholder': 'Username',  # Placeholder text
        })
    )
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={
            'class': 'input-box',  # CSS class for styling
            'placeholder': 'Email',  # Placeholder text
        })
    )
    favorite_team = forms.CharField(
        max_length=50,
        required=True,
        widget=forms.TextInput(attrs={
            'class': 'input-box',  # CSS class for styling
            'placeholder': 'Favorite Team',  # Placeholder text
        })
    )
    password1 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'input-box',  # CSS class for styling
            'placeholder': 'Password',  # Placeholder text
        })
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'input-box',  # CSS class for styling
            'placeholder': 'Re-Write Password',  # Placeholder text
        })
    )

    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'username', 'email', 'password1', 'password2', 'favorite_team']


# class LoginForm(AuthenticationForm):
#     class Meta:
#         fields = ['username', 'password']
class LoginForm(AuthenticationForm):
    username = forms.CharField(
        widget=forms.TextInput(attrs={
            'class': 'input-box',  # Apply your CSS class
            'placeholder': 'Username',  # Optional placeholder
        })
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'input-box',  # Apply your CSS class
            'placeholder': 'Password',  # Optional placeholder
        })
    )

    class Meta:
        fields = ['username', 'password']