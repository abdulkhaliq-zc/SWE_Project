from django.urls import path
from .views import sign_up, sign_in,home_page

urlpatterns = [
    path('sign-up/', sign_up, name='sign-up'),
    path('sign-in/', sign_in, name='sign-in'),
    path('homepage/', home_page, name='homepage'),
]
